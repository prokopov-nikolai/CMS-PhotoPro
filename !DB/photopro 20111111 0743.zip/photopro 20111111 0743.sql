﻿-- Скрипт сгенерирован Devart dbForge Studio for MySQL, Версия 5.0.50.1
-- Домашняя страница продукта: http://www.devart.com/ru/dbforge/mysql/studio
-- Дата скрипта: 11.11.2011 7:44:06
-- Версия сервера: 5.1.53-community
-- Версия клиента: 4.1

-- 
-- Отключение внешних ключей
-- 
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;

-- 
-- Установка кодировки, с использованием которой клиент будет посылать запросы на сервер
--
SET NAMES 'utf8';

--
-- Описание для таблицы ci_category
--
DROP TABLE IF EXISTS ci_category;
CREATE TABLE ci_category (
  category_id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Идентификатор категории',
  category_url VARCHAR(255) NOT NULL COMMENT 'Часть урла категории',
  category_title VARCHAR(255) NOT NULL COMMENT 'Название категории',
  category_keywords VARCHAR(255) DEFAULT NULL COMMENT 'Ключевики для категории',
  category_description TEXT DEFAULT NULL COMMENT 'Описание категории',
  PRIMARY KEY (category_id, category_url),
  UNIQUE INDEX category_id (category_id),
  UNIQUE INDEX category_url (category_url)
)
ENGINE = INNODB
AUTO_INCREMENT = 2
AVG_ROW_LENGTH = 16384
CHARACTER SET utf8
COLLATE utf8_general_ci;

--
-- Описание для таблицы ci_log
--
DROP TABLE IF EXISTS ci_log;
CREATE TABLE ci_log (
  `key` VARCHAR(255) DEFAULT NULL,
  value VARCHAR(255) DEFAULT NULL,
  `date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)
ENGINE = INNODB
AVG_ROW_LENGTH = 168
CHARACTER SET latin1
COLLATE latin1_swedish_ci;

--
-- Описание для таблицы ci_sessions
--
DROP TABLE IF EXISTS ci_sessions;
CREATE TABLE ci_sessions (
  session_id VARCHAR(40) NOT NULL DEFAULT '0',
  ip_address VARCHAR(16) NOT NULL DEFAULT '0',
  user_agent VARCHAR(120) NOT NULL,
  last_activity INT(10) UNSIGNED NOT NULL DEFAULT 0,
  user_data TEXT DEFAULT NULL,
  PRIMARY KEY (session_id),
  INDEX last_activity_idx (last_activity)
)
ENGINE = MYISAM
AVG_ROW_LENGTH = 612
CHARACTER SET utf8
COLLATE utf8_general_ci;

--
-- Описание для таблицы ci_user
--
DROP TABLE IF EXISTS ci_user;
CREATE TABLE ci_user (
  user_uniqid CHAR(22) NOT NULL COMMENT 'Идентификатор пользователя',
  user_email VARCHAR(255) NOT NULL COMMENT 'email пользователя',
  user_password VARCHAR(50) NOT NULL COMMENT 'Пароль в md5',
  user_last_name VARCHAR(255) DEFAULT NULL COMMENT 'Фамилия',
  user_first_name VARCHAR(255) DEFAULT NULL COMMENT 'Имя пользователя',
  user_patronymic VARCHAR(255) DEFAULT NULL COMMENT 'Отчество',
  user_sex TINYINT(1) UNSIGNED DEFAULT NULL COMMENT 'Пол пользователя (0 - ж, 1 - м)',
  user_about TEXT DEFAULT NULL COMMENT 'О себе',
  user_site VARCHAR(255) DEFAULT NULL COMMENT 'Сайт',
  user_subscribe TINYINT(1) UNSIGNED NOT NULL DEFAULT 1 COMMENT 'Подписка на новости',
  user_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT 'Дата регистрации',
  PRIMARY KEY (user_uniqid),
  UNIQUE INDEX `email-pass` (user_email, user_password)
)
ENGINE = INNODB
AVG_ROW_LENGTH = 16384
CHARACTER SET utf8
COLLATE utf8_general_ci
COMMENT = 'Таблица всех пользователей';

--
-- Описание для таблицы ci_vote
--
DROP TABLE IF EXISTS ci_vote;
CREATE TABLE ci_vote (
  vote_id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Идентификатор голосования',
  vote_question TEXT NOT NULL COMMENT 'Вопрос',
  vote_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT 'Дата добавления',
  user_uniqid CHAR(22) NOT NULL COMMENT 'Идентификатор пользователя',
  PRIMARY KEY (vote_id)
)
ENGINE = INNODB
AUTO_INCREMENT = 10
AVG_ROW_LENGTH = 16384
CHARACTER SET utf8
COLLATE utf8_general_ci;

--
-- Описание для таблицы ci_gallery
--
DROP TABLE IF EXISTS ci_gallery;
CREATE TABLE ci_gallery (
  gallery_id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Идентификатор галереи',
  gallery_url VARCHAR(255) NOT NULL COMMENT 'Часть урла галереи',
  gallery_title VARCHAR(255) NOT NULL COMMENT 'Название галереи',
  gallery_keywords VARCHAR(255) DEFAULT NULL COMMENT 'Ключевые слова',
  gallery_description TEXT DEFAULT NULL COMMENT 'Описание галереи',
  gallery_cover_id VARCHAR(13) DEFAULT NULL COMMENT 'Идентификатор обложки галереи',
  user_uniqid VARCHAR(22) NOT NULL COMMENT 'Индентификатор пользователя',
  PRIMARY KEY (gallery_id, gallery_url),
  UNIQUE INDEX gallery_id (gallery_id),
  UNIQUE INDEX gallery_url (gallery_url),
  INDEX user_gallery (user_uniqid),
  CONSTRAINT user_gallery FOREIGN KEY (user_uniqid)
    REFERENCES ci_user(user_uniqid) ON DELETE RESTRICT ON UPDATE RESTRICT
)
ENGINE = INNODB
AUTO_INCREMENT = 9
AVG_ROW_LENGTH = 4096
CHARACTER SET utf8
COLLATE utf8_general_ci;

--
-- Описание для таблицы ci_page
--
DROP TABLE IF EXISTS ci_page;
CREATE TABLE ci_page (
  page_id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Идентификатор страницы',
  page_url VARCHAR(255) NOT NULL,
  page_content TEXT DEFAULT NULL COMMENT 'Текст страницы',
  page_title VARCHAR(255) DEFAULT NULL COMMENT 'Заголовок страницы',
  page_keywords VARCHAR(255) DEFAULT NULL COMMENT 'Ключевые слова для страницы',
  page_description VARCHAR(255) DEFAULT NULL COMMENT 'Описание для страницы',
  page_date_add TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT 'Дата создания страницы',
  page_date_modified DATETIME DEFAULT NULL COMMENT 'Время обновления записи',
  category_id INT(11) UNSIGNED NOT NULL COMMENT 'Идетнификатор категории',
  user_id CHAR(22) NOT NULL COMMENT 'Идентификатор пользователя',
  PRIMARY KEY (page_id, page_url),
  INDEX IX_ci_page_category_id (category_id),
  INDEX user_page (user_id),
  CONSTRAINT category_page FOREIGN KEY (category_id)
    REFERENCES ci_category(category_id) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT user_page FOREIGN KEY (user_id)
    REFERENCES ci_user(user_uniqid) ON DELETE RESTRICT ON UPDATE RESTRICT
)
ENGINE = INNODB
AUTO_INCREMENT = 1
CHARACTER SET utf8
COLLATE utf8_general_ci;

--
-- Описание для таблицы ci_user_admin
--
DROP TABLE IF EXISTS ci_user_admin;
CREATE TABLE ci_user_admin (
  user_uniqid CHAR(22) NOT NULL COMMENT 'Идентификатор пользователя администратора',
  PRIMARY KEY (user_uniqid),
  UNIQUE INDEX user_id (user_uniqid),
  CONSTRAINT user_admin FOREIGN KEY (user_uniqid)
    REFERENCES ci_user(user_uniqid) ON DELETE CASCADE ON UPDATE CASCADE
)
ENGINE = INNODB
AVG_ROW_LENGTH = 16384
CHARACTER SET utf8
COLLATE utf8_general_ci;

--
-- Описание для таблицы ci_vote_answer
--
DROP TABLE IF EXISTS ci_vote_answer;
CREATE TABLE ci_vote_answer (
  answer_id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Идентификатор ответа',
  answer_text TEXT DEFAULT NULL COMMENT 'Текст ответа',
  vote_id INT(11) UNSIGNED NOT NULL COMMENT 'Идентификатор опроса',
  PRIMARY KEY (answer_id),
  INDEX FK_ci_vote_answer_ci_vote_vote_id (vote_id),
  CONSTRAINT FK_ci_vote_answer_ci_vote_vote_id FOREIGN KEY (vote_id)
    REFERENCES ci_vote(vote_id) ON DELETE CASCADE ON UPDATE CASCADE
)
ENGINE = INNODB
AUTO_INCREMENT = 35
AVG_ROW_LENGTH = 5461
CHARACTER SET utf8
COLLATE utf8_general_ci;

--
-- Описание для таблицы ci_image
--
DROP TABLE IF EXISTS ci_image;
CREATE TABLE ci_image (
  image_id CHAR(13) NOT NULL COMMENT 'Идентификатор картинки',
  image_name VARCHAR(255) DEFAULT NULL COMMENT 'Назнание файла в url',
  image_filename VARCHAR(255) NOT NULL COMMENT 'Название файла оригинала картинки',
  image_width SMALLINT(6) UNSIGNED NOT NULL DEFAULT 0 COMMENT 'Ширина изображения',
  image_height SMALLINT(6) UNSIGNED NOT NULL DEFAULT 0 COMMENT 'Высота изображения',
  image_size INT(11) UNSIGNED NOT NULL DEFAULT 0 COMMENT 'Размер изображения',
  gallery_id INT(11) UNSIGNED NOT NULL COMMENT 'Идентификатор галереи',
  user_uniqid VARCHAR(22) NOT NULL COMMENT 'Идентификатор пользователя',
  PRIMARY KEY (image_id),
  INDEX gallery_image (gallery_id),
  INDEX user_image (user_uniqid),
  CONSTRAINT gallery_image FOREIGN KEY (gallery_id)
    REFERENCES ci_gallery(gallery_id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT user_image FOREIGN KEY (user_uniqid)
    REFERENCES ci_user(user_uniqid) ON DELETE RESTRICT ON UPDATE RESTRICT
)
ENGINE = INNODB
AVG_ROW_LENGTH = 2048
CHARACTER SET utf8
COLLATE utf8_general_ci;

--
-- Описание для таблицы ci_vote_log
--
DROP TABLE IF EXISTS ci_vote_log;
CREATE TABLE ci_vote_log (
  answer_id INT(11) UNSIGNED NOT NULL,
  session_id VARCHAR(255) DEFAULT NULL,
  INDEX FK_ci_vote_log_ci_vote_answer_answer_id (answer_id),
  CONSTRAINT FK_ci_vote_log_ci_vote_answer_answer_id FOREIGN KEY (answer_id)
    REFERENCES ci_vote_answer(answer_id) ON DELETE CASCADE ON UPDATE CASCADE
)
ENGINE = INNODB
AVG_ROW_LENGTH = 1365
CHARACTER SET utf8
COLLATE utf8_general_ci;

--
-- Описание для таблицы ci_tag
--
DROP TABLE IF EXISTS ci_tag;
CREATE TABLE ci_tag (
  tag_name VARCHAR(255) NOT NULL COMMENT 'Сам тег',
  image_id CHAR(13) NOT NULL COMMENT 'Идентификатор картинки',
  INDEX image_id (image_id),
  INDEX tag_name (tag_name),
  CONSTRAINT image_id FOREIGN KEY (image_id)
    REFERENCES ci_image(image_id) ON DELETE CASCADE ON UPDATE CASCADE
)
ENGINE = INNODB
AVG_ROW_LENGTH = 2048
CHARACTER SET utf8
COLLATE utf8_general_ci;

-- 
-- Вывод данных для таблицы ci_category
--
INSERT INTO ci_category VALUES 
  (1, 'novosti', 'Новости', 'Новости', 'НовостиНовостиНовостиНовостиНовости<br/>');

-- 
-- Вывод данных для таблицы ci_log
--
INSERT INTO ci_log VALUES 
  ('visite', '127.0.0.1', '2011-10-13 23:45:06'),
  ('visite', '127.0.0.1', '2011-10-14 00:42:17'),
  ('visite', '127.0.0.1', '2011-10-14 00:42:29'),
  ('visite', '192.168.1.4', '2011-10-14 20:48:53'),
  ('visite', '192.168.1.4', '2011-10-14 21:00:54'),
  ('visite', '192.168.1.4', '2011-10-14 21:01:00'),
  ('visite', '127.0.0.1', '2011-10-17 11:18:17'),
  ('visite', '127.0.0.1', '2011-10-17 11:20:25'),
  ('visite', '127.0.0.1', '2011-10-17 11:20:32'),
  ('visite', '127.0.0.1', '2011-10-17 11:20:55'),
  ('visite', '127.0.0.1', '2011-10-17 11:22:21'),
  ('visite', '127.0.0.1', '2011-10-17 12:25:40'),
  ('visite', '127.0.0.1', '2011-10-17 12:25:45'),
  ('visite', '127.0.0.1', '2011-10-17 14:55:27'),
  ('visite', '127.0.0.1', '2011-10-18 09:18:31'),
  ('visite', '127.0.0.1', '2011-10-18 16:40:42'),
  ('visite', '127.0.0.1', '2011-10-19 09:24:39'),
  ('visite', '127.0.0.1', '2011-10-19 09:31:42'),
  ('visite', '127.0.0.1', '2011-10-19 14:01:49'),
  ('visite', '127.0.0.1', '2011-10-21 10:16:42'),
  ('visite', '127.0.0.1', '2011-10-21 10:34:52'),
  ('visite', '127.0.0.1', '2011-10-24 09:21:41'),
  ('visite', '127.0.0.1', '2011-10-24 09:28:41'),
  ('visite', '127.0.0.1', '2011-10-24 09:34:52'),
  ('visite', '127.0.0.1', '2011-10-24 09:36:34'),
  ('visite', '127.0.0.1', '2011-10-24 09:37:55'),
  ('visite', '127.0.0.1', '2011-10-24 09:37:56'),
  ('visite', '127.0.0.1', '2011-10-24 09:38:17'),
  ('visite', '127.0.0.1', '2011-10-24 09:39:10'),
  ('visite', '127.0.0.1', '2011-10-24 09:45:16'),
  ('visite', '127.0.0.1', '2011-10-24 09:47:41'),
  ('visite', '127.0.0.1', '2011-10-24 09:47:42'),
  ('visite', '127.0.0.1', '2011-10-24 09:47:42'),
  ('visite', '127.0.0.1', '2011-10-24 09:47:43'),
  ('visite', '127.0.0.1', '2011-10-24 09:47:43'),
  ('visite', '127.0.0.1', '2011-10-24 09:48:17'),
  ('visite', '127.0.0.1', '2011-10-24 09:50:20'),
  ('visite', '127.0.0.1', '2011-10-24 09:50:32'),
  ('visite', '127.0.0.1', '2011-10-24 09:50:41'),
  ('visite', '127.0.0.1', '2011-10-24 09:53:31'),
  ('visite', '127.0.0.1', '2011-10-24 09:54:15'),
  ('visite', '127.0.0.1', '2011-10-24 09:54:16'),
  ('visite', '127.0.0.1', '2011-10-24 09:58:29'),
  ('visite', '127.0.0.1', '2011-10-24 09:59:18'),
  ('visite', '127.0.0.1', '2011-10-24 10:01:05'),
  ('visite', '127.0.0.1', '2011-10-24 10:02:17'),
  ('visite', '127.0.0.1', '2011-10-24 10:02:48'),
  ('visite', '127.0.0.1', '2011-10-24 10:03:35'),
  ('visite', '127.0.0.1', '2011-10-24 10:03:54'),
  ('visite', '127.0.0.1', '2011-10-24 10:07:30'),
  ('visite', '127.0.0.1', '2011-10-24 10:11:48'),
  ('visite', '127.0.0.1', '2011-10-24 10:13:53'),
  ('visite', '127.0.0.1', '2011-10-24 10:18:45'),
  ('visite', '127.0.0.1', '2011-10-24 10:22:49'),
  ('visite', '127.0.0.1', '2011-10-24 10:23:50'),
  ('visite', '127.0.0.1', '2011-10-24 10:24:05'),
  ('visite', '127.0.0.1', '2011-10-24 10:24:21'),
  ('visite', '127.0.0.1', '2011-10-24 10:24:42'),
  ('visite', '127.0.0.1', '2011-10-24 10:35:56'),
  ('visite', '127.0.0.1', '2011-10-24 10:38:19'),
  ('visite', '127.0.0.1', '2011-10-24 10:48:33'),
  ('visite', '127.0.0.1', '2011-10-24 10:52:40'),
  ('visite', '127.0.0.1', '2011-10-24 10:52:51'),
  ('visite', '127.0.0.1', '2011-10-24 10:53:12'),
  ('visite', '127.0.0.1', '2011-10-24 10:53:35'),
  ('visite', '127.0.0.1', '2011-10-24 10:53:38'),
  ('visite', '127.0.0.1', '2011-10-24 10:53:42'),
  ('visite', '127.0.0.1', '2011-10-24 10:54:07'),
  ('visite', '127.0.0.1', '2011-10-24 10:55:02'),
  ('visite', '127.0.0.1', '2011-10-24 10:57:23'),
  ('visite', '127.0.0.1', '2011-10-24 10:57:55'),
  ('visite', '127.0.0.1', '2011-10-24 10:58:27'),
  ('visite', '127.0.0.1', '2011-10-24 10:59:25'),
  ('visite', '127.0.0.1', '2011-10-24 11:00:00'),
  ('visite', '127.0.0.1', '2011-10-24 11:00:22'),
  ('visite', '127.0.0.1', '2011-10-24 11:00:30'),
  ('visite', '127.0.0.1', '2011-10-24 11:00:43'),
  ('visite', '127.0.0.1', '2011-10-24 11:00:55'),
  ('visite', '127.0.0.1', '2011-10-24 11:01:05'),
  ('visite', '127.0.0.1', '2011-10-24 11:01:10'),
  ('visite', '127.0.0.1', '2011-10-24 11:02:00'),
  ('visite', '127.0.0.1', '2011-10-24 11:03:19'),
  ('visite', '127.0.0.1', '2011-10-24 11:03:33'),
  ('visite', '127.0.0.1', '2011-10-24 11:04:29'),
  ('visite', '127.0.0.1', '2011-10-24 11:05:26'),
  ('visite', '127.0.0.1', '2011-10-24 11:06:23'),
  ('visite', '127.0.0.1', '2011-10-25 09:01:51'),
  ('visite', '127.0.0.1', '2011-10-25 09:02:16'),
  ('visite', '127.0.0.1', '2011-10-25 09:02:57'),
  ('visite', '127.0.0.1', '2011-10-25 09:03:26'),
  ('visite', '127.0.0.1', '2011-10-25 09:03:38'),
  ('visite', '127.0.0.1', '2011-10-25 10:55:56'),
  ('visite', '127.0.0.1', '2011-10-25 10:56:19'),
  ('visite', '127.0.0.1', '2011-10-26 09:18:23'),
  ('visite', '127.0.0.1', '2011-10-26 10:37:50'),
  ('visite', '127.0.0.1', '2011-10-26 10:37:55'),
  ('visite', '127.0.0.1', '2011-10-26 11:45:00');

-- 
-- Вывод данных для таблицы ci_sessions
--
INSERT INTO ci_sessions VALUES 
  ('0e4ae499dc094bcea403b31292587724', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; rv:7.0.1) Gecko/20100101 Firefox/7.0.1', 1319178892, 'a:12:{s:11:"user_uniqid";s:22:"4e973fc217240583774882";s:10:"user_email";s:26:"prokopov-nikolaj@yandex.ru";s:13:"user_password";s:32:"6715eb8de8b4e4b337c7c3bdc3729068";s:14:"user_last_name";s:16:"Прокопов";s:15:"user_first_name";s:14:"Николай";s:15:"user_patronymic";s:16:"Иванович";s:8:"user_sex";s:1:"1";s:10:"user_about";N;s:9:"user_site";N;s:14:"user_subscribe";s:1:"1";s:9:"user_date";s:19:"2011-10-13 23:45:06";s:10:"user_admin";s:22:"4e973fc217240583774882";}');

-- 
-- Вывод данных для таблицы ci_user
--
INSERT INTO ci_user VALUES 
  ('4e973fc217240583774882', 'prokopov-nikolaj@yandex.ru', '6715eb8de8b4e4b337c7c3bdc3729068', 'Прокопов', 'Николай', 'Иванович', 1, NULL, NULL, 1, '2011-10-13 23:45:06');

-- 
-- Вывод данных для таблицы ci_vote
--
INSERT INTO ci_vote VALUES 
  (9, 'Новый опрос', '2011-10-15 03:06:41', '4e973fc217240583774882');

-- 
-- Вывод данных для таблицы ci_gallery
--
INSERT INTO ci_gallery VALUES 
  (5, 'galereya-na-glavnoy', 'Галерея на главной', 'Галерея на главной', 'Фотография стала для нас всем<br/>', '4ea7b6377df7b', '4e973fc217240583774882'),
  (6, 'vtoraya-galereya', 'Вторая галерея', 'Вторая галерея', 'Вторая галерея<br/>', NULL, '4e973fc217240583774882'),
  (7, 'devushki', 'Девушки', 'Девушки', 'Девушки<br/>', NULL, '4e973fc217240583774882'),
  (8, 'esche-odna-galereya-s-dlinnim-nazvaniem', 'Еще одна галерея с длинным названием', 'Еще одна галерея с длинным названием', 'Еще одна галерея с длинным названием<br/>', NULL, '4e973fc217240583774882');

-- 
-- Вывод данных для таблицы ci_page
--
-- Таблица не содержит данных

-- 
-- Вывод данных для таблицы ci_user_admin
--
INSERT INTO ci_user_admin VALUES 
  ('4e973fc217240583774882');

-- 
-- Вывод данных для таблицы ci_vote_answer
--
INSERT INTO ci_vote_answer VALUES 
  (32, 'Ответ 1', 9),
  (33, 'Ответ 3', 9),
  (34, 'Ответ 2', 9);

-- 
-- Вывод данных для таблицы ci_image
--
INSERT INTO ci_image VALUES 
  ('4ea7b63494f76', 'rewalls.com-50625-skqiuf.jpg', 'rewalls.com-50625-skqiuf3494f76.jpg', 1140, 713, 484928, 5, '4e973fc217240583774882'),
  ('4ea7b63615829', 'rewalls.com-50627-rwibur.jpg', 'rewalls.com-50627-rwibur3615829.jpg', 1140, 713, 592818, 5, '4e973fc217240583774882'),
  ('4ea7b6377df7b', 'rewalls.com-50634-rfitml.jpg', 'rewalls.com-50634-rfitml377df7b.jpg', 1140, 642, 404879, 5, '4e973fc217240583774882'),
  ('4ea7b638d10a5', 'rewalls.com-50671-mrobhy.jpg', 'rewalls.com-50671-mrobhy38d10a5.jpg', 1140, 713, 542077, 5, '4e973fc217240583774882'),
  ('4ea7b63a4a63b', 'rewalls.com-50719-pgpmbe.jpg', 'rewalls.com-50719-pgpmbe3a4a63b.jpg', 1140, 713, 540152, 5, '4e973fc217240583774882'),
  ('4ebb47a2e5af4', 'dsc09248-wipspv.jpg', 'dsc09248-wipspva2e5af4.jpg', 1054, 790, 140332, 6, '4e973fc217240583774882'),
  ('4ebc2adb4e697', 'telka-vlvakf.jpg', 'telka-vlvakfdb4e697.jpg', 709, 790, 91719, 7, '4e973fc217240583774882'),
  ('4ebc31ec997a2', '555-wwpfyp.png', '555-wwpfypec997a2.png', 785, 790, 430908, 8, '4e973fc217240583774882');

-- 
-- Вывод данных для таблицы ci_vote_log
--
INSERT INTO ci_vote_log VALUES 
  (33, NULL),
  (32, NULL),
  (32, NULL),
  (34, NULL),
  (32, NULL),
  (32, NULL),
  (32, NULL),
  (32, NULL),
  (32, NULL),
  (32, NULL),
  (32, NULL),
  (32, NULL);

-- 
-- Вывод данных для таблицы ci_tag
--
INSERT INTO ci_tag VALUES 
  ('11', '4ea7b63494f76'),
  ('11', '4ea7b63615829'),
  ('33', '4ea7b6377df7b'),
  ('22', '4ea7b638d10a5'),
  ('33', '4ea7b63a4a63b'),
  ('DSC09248.JPG', '4ebb47a2e5af4'),
  ('telka.jpg', '4ebc2adb4e697'),
  ('555.png', '4ebc31ec997a2');

-- 
-- Включение внешних ключей
-- 
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;